package net.appdojo.demo.services;

import net.appdojo.demo.models.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class MainServiceTest {
    @Autowired
    MainService service;
    @Test
    void main() {
    }

    @Test
    void getUser() {
        try {
            User user = service.getUser(1);
            assertNotNull(user);
            System.out.println(user);
        } catch (Exception e) {
            e.printStackTrace();
            //throw new RuntimeException(e);
        }
    }

    @Test
    void auth() {
    }

    @Test
    void getUsers() {
    }

    @Test
    void save() {
    }

    @Test
    void generateToken() {
    }
}