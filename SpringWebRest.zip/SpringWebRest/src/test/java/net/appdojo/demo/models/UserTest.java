package net.appdojo.demo.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class UserTest {

    @Test
    void testToString() {
    }

    @Test
    void setUsername() {
    }

    @Test
    void getFullName() {
    }

    @Test
    void setFullName() {
    }
}