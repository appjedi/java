package net.appdojo.demo.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.appdojo.demo.services.HTTPRequests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;

//@WebMvcTest(APIController.class)

class APIControllerTest {
// For converting Java objects to JSON
    HTTPRequests request = new HTTPRequests();
    @Test
    void testAuthUser_ValidRequest() throws Exception {
        try {
            String jsonTemp = "{\"userId\":%d, \"username\":\"%s\", \"password\":\"%s\", \"email\":\"%s\",\"fullName\":\"%s\",\"roleId\":%d, \"status\":%d}";
            String jsonData = String.format(jsonTemp, 1, "bob", "asdf","bob@test2.com","Bob Test II", 0, 0);
            String response =request.sendPostRequest("http://localhost:8080/api/auth", jsonData);

           // String response = request.sendPostRequest("http://localhost:8080/auth/user", jsonData);
            System.out.println(response);
        } catch (Exception e) {
            e.printStackTrace();
            //throw new RuntimeException(e);
        }
    }
    @Test
    void auth() {

    }

    @Test
    void getAuthUser() {
    }

    @Test
    void logout() {
    }

    @Test
    void postUser() {
    }

    @Test
    void getUser() {
        try {

        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void testGetUser() {
    }

    @Test
    void getUsers() {
    }
}