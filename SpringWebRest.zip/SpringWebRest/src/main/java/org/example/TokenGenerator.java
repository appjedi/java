package org.example;

import java.security.SecureRandom;
import java.util.Base64;

public class TokenGenerator {

    public static String generateToken(int length) {
        SecureRandom random = new SecureRandom();
        byte[] bytes = new byte[length];
        random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    public static void main(String[] args) {
        int tokenLength = 32; // Example length: 32 bytes
        if (args.length > 0) {
            try {
                tokenLength = Integer.parseInt(args[0]);
            }catch (NumberFormatException e) {
                tokenLength = 32;
            }
        }
        String token = generateToken(tokenLength);
        System.out.println("Generated token: " + token);
    }
}
