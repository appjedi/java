package net.appdojo.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import net.appdojo.demo.models.User;
@Component
public class UserDAO extends Database{
	public static void main (String[]args)
	{



		testAddUser();
		//testAuth("bob", "Test1234");
	}
	public static void testAuth(String username, String password)
	{
		//UserDAO dao = new UserDAO();
		Database db = new Database();
		try {
			String ps = "SELECT * FROM users where username=? AND password=?";
			String sp = "call usp_user_auth(?,?)";
			ResultSet rs = db.query(sp, username, password);

			if (rs == null || !rs.next()) {
				System.err.println("Query failed");
			} else {
				String msg = rs.getString("message");
				System.out.println(msg);
			}
		}catch (SQLException sqlex){
			System.err.println(sqlex);
			sqlex.printStackTrace();
		}catch (Exception ex){
			ex.printStackTrace();
		}
	}
	public static void testAddUser()
	{
		User user=new User();
		user.setUserId(5);
		user.setUsername("testerb");
		user.setPassword("TestJava");
		user.setRoleId(2);
		user.setStatus(1);
		user.setFullName("Admin Tester");
		user.setEmail("admin@test.com");
		UserDAO dao = new UserDAO();
		user=dao.save(user);
		System.out.println(user);
	}
	public User getUser(int id)
	{
		Database db = new Database();
		try {
			ResultSet rs = db.getResultSet("SELECT * FROM users where id="+id);
        	
        	if (rs==null||!rs.next())
        	{
        		System.err.println ("Query failed");
        		return null;
        	}
        	User user = new User();
        	
        	user.setUserId(id);
        	user.setEmail(rs.getString("email"));
        	user.setUsername(rs.getString("username"));
        	user.setFullName(rs.getString("full_name"));
        	user.setStatus(rs.getInt("status"));
        	user.setRoleId(rs.getInt("role_id"));
        	return user;
		}catch (Exception ex)
		{
			return null;
		}
	}
	public User auth(String un, String pw)
	{
		Database db = new Database();
		try {
			String ps = "SELECT * FROM users where username=? AND password=?";
			String sp = "call usp_user_auth(?,?)";
			ResultSet rs = db.query(ps,un,pw);

        	if (rs==null||!rs.next())
        	{
        		System.err.println ("Query failed");
        		return null;
        	}

        	User user = new User();

        	user.setUserId(rs.getInt("id"));
        	user.setEmail(rs.getString("email"));
        	user.setUsername(rs.getString("username"));
        	user.setFullName(rs.getString("full_name"));
        	user.setStatus(rs.getInt("status"));
        	user.setRoleId(rs.getInt("role_id"));
        	return user;
		}catch (Exception ex)
		{
			ex.printStackTrace();
			return null;
		}finally {
			db.close();
		}
	}
	public List<User> getUsers()
	{
		Database db = new Database();
		try {
			ResultSet rs = db.getResultSet("SELECT * FROM users");
        	
        	if (rs==null||!rs.next())
        	{
        		System.err.println ("Query failed");
        		return null;
        	}
        	List<User>users=new ArrayList<User>();
        	do {
	        	User user = new User();
	        	
	        	user.setUserId(rs.getInt("id"));
	        	user.setEmail(rs.getString("email"));
	        	user.setUsername(rs.getString("username"));
	        	user.setFullName(rs.getString("full_name"));
	        	user.setStatus(rs.getInt("status"));
	        	user.setRoleId(rs.getInt("role_id"));
	        	users.add(user);
        	}while (rs.next());
        	return users;
		}catch (Exception ex)
		{
			return null;
		}
	}
	public User save (User user)
	{
		Database db = new Database();
		try {
			String sp="call usp_user_save";
			ResultSet rs = db.query(sp, user.getUserId(),user.getUsername(),user._pw(),user.getFullName(),user.getEmail(),"",user.getRoleId());
			if(rs==null||!rs.next())
			{
				return null;
			}
			int id=rs.getInt("id");
			int status=rs.getInt("status");
			if (status==0)
			{
				System.err.println("User "+user.getUserId()+" nothing updated");
				return null;
			}
			System.out.println("User "+user.getUserId()+" saved "+id);
			user.setUserId(id);
			return user;
		}catch (Exception ex)
		{
			return null;
		}finally {
			db.close();
		}
		
	}
}
