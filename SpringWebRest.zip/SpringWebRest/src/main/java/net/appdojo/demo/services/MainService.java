package net.appdojo.demo.services;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.appdojo.demo.dao.UserDAO;
import net.appdojo.demo.models.User;

@Service
public class MainService {
	@Autowired
	UserDAO userDAO;
	public static void main(String[] args) {
		int tokenLength = 32; // Example length: 32 bytes
		if (args.length > 0) {
			try {
				tokenLength = Integer.parseInt(args[0]);
			}catch (NumberFormatException e) {
				tokenLength = 32;
			}
		}
		String token = generateToken(tokenLength);
		System.out.println("Generated token: " + token);
	}
	public User getUser(int id)
	{
		return userDAO.getUser(id);
	}
	public User auth(String un, String pw)
	{
		User u= userDAO.auth(un,pw);

		if (u!=null)
		{
			u.setToken(generateToken(32));
		}
		return u;
	}
	public List<User> getUsers()
	{
		return userDAO.getUsers();
	}
	public User save (User user)
	{
		return userDAO.save(user);
	}

	public static String generateToken(int length) {
		SecureRandom random = new SecureRandom();
		byte[] bytes = new byte[length];
		random.nextBytes(bytes);
		return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
	}
}
