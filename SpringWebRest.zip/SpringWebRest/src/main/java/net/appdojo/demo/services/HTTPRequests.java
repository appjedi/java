package net.appdojo.demo.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;

public class HTTPRequests {
    public static void main(String[] args) throws IOException {
        String jsonTemp = "{\"userId\":%d, \"username\":\"%s\", \"password\":\"%s\", \"email\":\"%s\",\"fullName\":\"%s\",\"roleId\":%d, \"status\":%d}";
        String jsonData = String.format(jsonTemp, 1, "bob", "Test1234","bob@test2.com","Bob Test II", 0, 0);

        System.out.println(jsonData);
        String content =sendPostRequest("http://localhost:8080/api/auth", jsonData);
        //String content = sendGet("http://localhost:8080/api/user/1");
        assertNotNull(content, "The value should not be null");
        System.out.println(content);
    }
    public static String sendGetRequest(String url) throws IOException {
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);
        return "";
    }
    public static String sendGet(String urlGet) {
        try {
            URL url = new URL(urlGet);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            if (responseCode >=200 && responseCode < 300) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                return response.toString();
            } else {
               return "GET request failed";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "GET request failed";
        }
    }
    public static String sendPostRequest(String urlPost, String jsonInputString) {
        try {
            URL url = new URL(urlPost);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);

            // JSON body
            //String jsonInputString = "{ \"title\": \"foo\", \"body\": \"bar\", \"userId\": 1 }";

            // Write JSON data to the request body
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                return response.toString();
            } else {
                return "POST request failed";
            }
            // Handle response (if needed)
        } catch (Exception e) {
            e.printStackTrace();
            return "POST request failed";
        }
    }
    public static String sendPutRequest(String urlPost, String jsonInputString) {
        try {
            URL url = new URL(urlPost);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("PUT");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);

            // JSON body
            //String jsonInputString = "{ \"title\": \"foo\", \"body\": \"bar\", \"userId\": 1 }";

            // Write JSON data to the request body
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                return response.toString();
            } else {
                return "PUT request failed";
            }
            // Handle response (if needed)
        } catch (Exception e) {
            e.printStackTrace();
            return "PUT request failed";
        }
    }
}
