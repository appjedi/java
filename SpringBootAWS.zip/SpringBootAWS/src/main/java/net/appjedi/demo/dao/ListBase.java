package net.appjedi.demo.dao;

import java.sql.ResultSet;

public class ListBase {	
	public int process(ResultSet rs) {return 0;}
}
